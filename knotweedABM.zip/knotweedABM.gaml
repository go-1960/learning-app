/**
* Name: knotweedABM
* Based on the internal empty template. 
* Author: ermad
* Tags: 
*/


model knotweedABM

/* Insert your model definition here */
global {
	//-----------------------------------------------------
	// PARAMÈTRES
	//-----------------------------------------------------
	float K <- 12.7;
	float L <- 0.26;
	float a0 <- 1.7;

	float b_max <- 0.18;
	
	float distance_parent <-0.2;
	float distance_competition <- 0.15;
	
	float gamma_shape <- 4.34;
	float gamma_scale <- 2.36;
	
	float death_scale <- 1.12;
	float death_decay <- 2.32;
	
	float mowing_param <- 0.11;
	float tau;
	float proportion_mowing <- 0.9;
	
	float dt <- 0.1;
	float T ;
	
	int initial_population <- 1500;
	
	int population_size<- length(crown);
    float invaded_area;
    
    int sim_id <- 0;
    
	
	
	//-----------------------------------------------------
	// INITIALISATION
	//-----------------------------------------------------
	init {
	
		create crown number: initial_population {
			biomass <- a0;
		}
		
		
		
		
	}
	
	
	
	//-----------------------------------------------------
	// DYNAMIQUE GLOBALE
	//-----------------------------------------------------
	reflex global_step when: (time < T) {
		ask crown {
			do grow;
			do reproduce;
			do mortality;
		}
		// FAUCHE
		if(flip(tau * dt)){
			ask crown {
				if(flip(proportion_mowing)){
					do mow;
				}
			}
		}
	}
	
	
	//reflex update_metrics {
		//population_size <- length(crown);
		//invaded_area <- length(crown) * (pi * (distance_parent)^2);
		
		
	//}
	
	reflex save_data {

        save [
        	tau,
        	T,
        	sim_id,
            time,
            length(crown)
        ]
        to: "sampling1.csv"
        type: csv
        rewrite: false;
        

    }
		
}


    //-----------------------------------------------------
	// AGENTS
	//-----------------------------------------------------
species crown {
	float size <- 1.0;
	rgb color <- #green;
	float biomass;
	
	environment_cell my_cell <- one_of (environment_cell);
		
	init {
		location <- my_cell.location;
	}
	
	//-----------------------------------------------------
	// CROISSANCE
	//-----------------------------------------------------
	action grow {
		biomass <- biomass + L * (K - biomass)*dt;
	}
	
	//-----------------------------------------------------
	// REPRODUCTION
	//-----------------------------------------------------
	action reproduce {
		list<crown> neigh <- crown at_distance distance_parent;
		if(length(neigh) < 2 and flip(b_max*dt)){
			float d <- gamma_rnd(gamma_shape, gamma_scale);
			float angle <- rnd(360.0);
			float new_x <- location.x + d*cos(angle);
			float new_y <- location.y + d*sin(angle);
			point new_loc <- {new_x, new_y};
			
			// Vérifier compétition
			list<crown> close <- crown at_distance distance_competition;
			if(length(close) = 0){
				create crown {
					location <- new_loc;
					biomass <- a0;
				}
			}
		}
	}
	
	//-----------------------------------------------------
	// MORTALITÉ
	//-----------------------------------------------------
	action mortality {
		float p <- death_scale * exp(-death_decay*biomass)*dt;
		if(flip(p)){
			do die;
		}
	}
	
	//-----------------------------------------------------
	// FAUCHE
	//-----------------------------------------------------
	action mow {
		biomass <-biomass*(1 - exp(-mowing_param*biomass));
	}
	
	aspect base {
		draw circle(size) color:color;
	}
		
}

grid environment_cell width: 50 height: 50 neighbors: 4{
	
}

    //-----------------------------------------------------
	// AFFICHAGE
	//-----------------------------------------------------

//experiment explore_model type: batch until: time > T repeat: 50 {
	//parameter "tau" var: tau;
	
	//reflex save_results {
		
		//ask simulations {
		//	write write ;
		//	save population_size to:"results.csv" rewrite: (int(self) = 0) ? true : false header: true ;
		//}
	//}
//}

experiment export_tau0 type: batch repeat: 50 until: time > T {
	parameter "tau" var: tau min: 0.0 max: 15.0 step: 0.5;
	parameter "T" var: T min: 0.0 max: 16.0 step: 1;
	
	init {
        sim_id <- rnd(100000);  // identifiant unique
    }
	

}



