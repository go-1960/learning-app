
model KnotweedViability

global {

    // =====================================================
    // TEMPS ET DUREES
    // =====================================================

    float dt <- 1.0 / 12.0;

    int natural_duration_limit_months <- 420;
    int management_duration_months <- 192;

    int natural_months <- 0;
    int management_months <- 0;

    // =====================================================
    // ESPACE
    // =====================================================

    int grid_width <- 100;
    int grid_height <- 100;

    // =====================================================
    // SEUIL DE TRANSITION
    // =====================================================

    int initial_population <- 1;
    int target_population <- 500;

    // =====================================================
    // PARAMETRES BIOLOGIQUES
    // Valeurs reprises du modele fourni
    // =====================================================

    float K_biomass <- 12.7;
    float L_growth <- 0.26;
    float initial_biomass <- 1.73;

    float birth_rate_max <- 0.18;

    float distance_parent <- 0.2;
    float distance_competition <- 0.15;

    float gamma_shape <- 4.34;
    float gamma_scale <- 2.36;

    float death_scale <- 1.12;
    float death_decay <- 2.32;

    // =====================================================
    // PARAMETRES DE FAUCHE
    // =====================================================

    float tau_management <- 1.0;
    float proportion_mowing <- 0.90;
    float mowing_parameter <- 0.11;

    bool mowing_event_this_month <- false;

    int total_mowing_events <- 0;

    // =====================================================
    // PHASES DE SIMULATION
    // =====================================================

    string phase <- "NATURAL";

    bool simulation_finished <- false;

    // =====================================================
    // ETAT COURANT
    // X(t) = (A(t), N(t))
    // =====================================================

    float current_area <- 0.0;
    int current_population <- 0;

    // =====================================================
    // ETAT INITIAL DE LA GESTION
    // Ces valeurs sont figees a la transition
    // =====================================================

    float A0 <- 0.0;
    int N0 <- 0;

    // =====================================================
    // INDICATEURS DE VIABILITE
    // =====================================================

    float area_viability_limit <- 0.0;
    float population_viability_limit <- 0.0;

    bool in_K <- false;
    bool ever_reached_K <- false;
    bool remained_in_K <- true;

    int time_to_K_management_month <- -1;
    bool is_batch <- false;
    float T;
    int sim_id <- 0;

    // =====================================================
    // CALCUL DE LA SURFACE
    // Enveloppe convexe des positions des couronnes
    // =====================================================

    action update_state {

        current_population <- length(Couronne);

        if (current_population < 3) {

            current_area <- 0.0;

        } else {

            list<point> crown_points <-
                Couronne collect each.location;

            geometry crown_geometry <-
                geometry(crown_points);

            geometry hull <-
                convex_hull(crown_geometry);

            current_area <- hull.area;
        }
    }

    // =====================================================
    // CAPTURE DE L'ETAT INITIAL DE GESTION
    // A appeler UNE SEULE FOIS
    // =====================================================

    action define_reference_state {

        do update_state;

        N0 <- current_population;
        A0 <- current_area;

        area_viability_limit <- 0.05 * A0;
        population_viability_limit <- 0.05 * N0;

        write "==========================================";
        write "ETAT INITIAL DE LA GESTION";
        write "Mois naturels = " + natural_months;
        write "Temps naturel (ans) = "
            + (natural_months * dt);
        write "N0 = " + N0;
        write "A0 = " + A0;
        write "Seuil de population = "
            + population_viability_limit;
        write "Seuil de surface = "
            + area_viability_limit;
        write "==========================================";
    }

    // =====================================================
    // DYNAMIQUE BIOLOGIQUE
    // Croissance, reproduction et mortalite
    // =====================================================

    action biological_dynamics {

        // 1. Croissance de toutes les couronnes

        ask Couronne {
            do grow;
        }

        // 2. Reproduction

        ask Couronne {
            do reproduce;
        }

        // 3. Mortalite

        ask Couronne {
            do mortality;
        }
    }

    // =====================================================
    // SUIVI DE LA VIABILITE
    // =====================================================

    action update_viability {

        in_K <-
            current_area <= area_viability_limit
            and
            current_population <= population_viability_limit;

        if (in_K and !ever_reached_K) {

            ever_reached_K <- true;

            time_to_K_management_month <-
                management_months;

            write "------------------------------------------";
            write "PREMIERE ENTREE DANS K";
            write "Mois de gestion = " + management_months;
            write "Population = " + current_population;
            write "Surface = " + current_area;
            write "------------------------------------------";
        }

        if (ever_reached_K and !in_K) {

            remained_in_K <- false;
        }
    }

    // =====================================================
    // REFLEXE PRINCIPAL
    // Une seule machine a etats pour eviter les conflits
    // entre les reflexes des deux phases
    // =====================================================

    reflex simulation_step
    when: !simulation_finished {

        // ================================================
        // PHASE 1 : INVASION NATURELLE
        // ================================================

        if (phase = "NATURAL") {

            do biological_dynamics;

            do update_state;

            natural_months <- natural_months + 1;
			do save_current_state;
            // Le seuil doit etre strictement depasse.

            if (current_population > target_population) {

                // Capture de l'etat apres le franchissement.

                do define_reference_state;

                phase <- "MANAGEMENT";
                management_months <- 0;

                write "";
                write "##########################################";
                write "TRANSITION : INVASION -> GESTION";
                write "Population naturelle = "
                    + current_population;
                write "Surface naturelle = "
                    + current_area;
                write "Frequence tau = "
                    + tau_management;
                write "##########################################";
                write "";

            } else if (
                natural_months >= natural_duration_limit_months
            ) {

                phase <- "FINISHED";
                simulation_finished <- true;

                write "==========================================";
                write "ECHEC DU SEUIL NATUREL";
                write "La population n'a pas depasse "
                    + target_population;
                write "Population finale = "
                    + current_population;
                write "Mois naturels = " + natural_months;
                write "La gestion n'est pas declenchee.";
                write "==========================================";
                
                if (!is_batch) {
			        do pause;
			    }

                //do pause;
            }
        }

        // ================================================
        // PHASE 2 : GESTION PAR FAUCHE
        // Commence au cycle suivant la transition
        // ================================================

        else if (phase = "MANAGEMENT") {

            mowing_event_this_month <- false;

            // Dynamique biologique entre les interventions.

            do biological_dynamics;

            // Intervention probabiliste selon tau.

            ask Gestionnaire {
                do manage;
            }

            // Etat apres dynamique et eventuelle fauche.

            do update_state;

            management_months <- management_months + 1;

            // Indicateurs de viabilite.

            do update_viability;
            do save_current_state;

            // --------------------------------------------
            // AFFICHAGE DE CHAQUE MOIS DE GESTION
            // --------------------------------------------

            write "------------------------------------------";
            write "PHASE DE GESTION";
            write "Mois de gestion = " + management_months;
            write "Temps de gestion (ans) = "
                + (management_months * dt);
            write "Tau = " + tau_management;
            write "Population N(t) = "
                + current_population;
            write "Surface A(t) = " + current_area;
            write "Intervention ce mois = "
                + mowing_event_this_month;
            write "Nombre total de fauches = "
                + total_mowing_events;
            write "Dans K = " + in_K;
            write "------------------------------------------";

            // --------------------------------------------
            // FIN DE LA GESTION
            // --------------------------------------------

            if (
                management_months
                >= management_duration_months
            ) {

                phase <- "FINISHED";
                simulation_finished <- true;

                write "";
                write "##########################################";
                write "FIN DE LA GESTION";
                write "Tau = " + tau_management;
                write "Duree = "
                    + management_months + " mois";
                write "Population initiale N0 = " + N0;
                write "Population finale = "
                    + current_population;
                write "Variation population (%) = "
                    + (
                        100.0
                        * (current_population - N0)
                        / N0
                    );
                write "Surface initiale A0 = " + A0;
                write "Surface finale = " + current_area;
                 write "Variation surface (%) = "
                    + (
                        100.0
                        * (current_area - A0)
                        / A0
                    );
                write "Nombre de fauches = "
                    + total_mowing_events;
                write "Entree dans K = " + ever_reached_K;
                write "Toujours dans K apres entree = "
                    + remained_in_K;
                write "##########################################";
                
                if (!is_batch) {
			        do pause;
			    }

                //do pause;
            }
        }
    }

    // =====================================================
    // INITIALISATION
    // =====================================================

    init {

        create Couronne number: initial_population {

            location <- {
                grid_width / 2.0,
                grid_height / 2.0
            };

            biomass <- initial_biomass;
            is_initial <- true;
        }

        // Le gestionnaire existe avant le debut de la gestion.

        create Gestionnaire number: 1;

        do update_state;

        write "==========================================";
        write "DEMARRAGE DU MODELE";
        write "Phase = " + phase;
        write "Population initiale = "
            + current_population;
        write "Surface initiale = " + current_area;
        write "Seuil de transition = "
            + target_population;
        write "Tau de gestion = " + tau_management;
        write "==========================================";
    }
    
    
    /*reflex save_result  {
    	
    	  save [
    		tau_management,
    		cycle,
    		management_months,
    		management_months * dt,
    		total_mowing_events,
    		current_area,
    		current_population,
    		in_K,
    		ever_reached_K,
    		remained_in_K
    	]
    	to: "../results/knotweed_viability.csv"
       format:"csv"
       rewrite: false;
       
    	}*/
    	
    	action save_current_state {

	    save [
	    	sim_id,
	        tau_management,
	        phase,
	        cycle,
	        natural_months,
	        management_months,
	        (natural_months + management_months) * dt,
	        total_mowing_events,
	        current_area,
	        current_population,
	        in_K,
	        ever_reached_K,
	        remained_in_K
	    ]
	    to: "../results/knotweed_viability1.csv"
	    format: "csv"
	    rewrite: false;
}
}


// =========================================================
// AGENT COURONNE
// =========================================================

species Couronne {

    float biomass <- initial_biomass;
    bool is_initial <- false;

    // -----------------------------------------------------
    // CROISSANCE DE LA BIOMASSE
    // -----------------------------------------------------

    action grow {

        biomass <-
            biomass
            + dt * L_growth * (K_biomass - biomass);

        if (biomass > K_biomass) {
            biomass <- K_biomass;
        }

        if (biomass < 0.0) {
            biomass <- 0.0;
        }
    }

    // -----------------------------------------------------
    // REPRODUCTION
    // -----------------------------------------------------

    action reproduce {

        int local_count <-
            length(
                Couronne where (
                    each distance_to self <= distance_parent
                )
            );

        // Le comptage inclut normalement la couronne elle-meme.
        // Le seuil <= 3 suit le critere local de l'article.

        if (local_count <= 3) {

            float birth_probability <-
                1.0 - exp(-birth_rate_max * dt);

            if (rnd(1.0) < birth_probability) {

                float dispersal_distance <-
                    gamma_rnd(gamma_shape, gamma_scale);

                float angle <- rnd(360.0);

                point new_position <- {
                    location.x
                        + dispersal_distance * cos(angle),
                    location.y
                        + dispersal_distance * sin(angle)
                };

                bool position_free <-
                    empty(
                        Couronne where (
                            each distance_to new_position
                                <= distance_competition
                        )
                    );

                bool inside_grid <-
                    new_position.x >= 0
                    and new_position.x < grid_width
                    and new_position.y >= 0
                    and new_position.y < grid_height;

                if (position_free and inside_grid) {

                    create Couronne {

                        location <- new_position;
                        biomass <- initial_biomass;
                        is_initial <- false;
                    }
                }
            }
        }
    }

    // -----------------------------------------------------
    // MORTALITE
    // -----------------------------------------------------

    action mortality {

        float mortality_rate <-
            death_scale * exp(-death_decay * biomass);

        // Probabilite correspondant a un taux instantane
        // de mortalite sur un pas dt.

        float mortality_probability <-
            1.0 - exp(-mortality_rate * dt);

        if (rnd(1.0) < mortality_probability) {
            do die;
        }
    }

    // -----------------------------------------------------
    // EFFET DE LA FAUCHE
    // Formulation du modele de reference
    // -----------------------------------------------------

    action mow {

        biomass <-
            biomass
            * (
                1.0
                - exp(-mowing_parameter * biomass)
            );

        if (biomass < 0.0) {
            biomass <- 0.0;
        }
    }

    // -----------------------------------------------------
    // AFFICHAGE
    // -----------------------------------------------------

    aspect base {

        draw circle(0.5) color: #darkgreen;
    }
}


// =========================================================
// AGENT GESTIONNAIRE
// =========================================================

species Gestionnaire {

    action manage {

        // Tau represente le nombre moyen d'interventions
        // par an. Une approximation mensuelle du processus
        // de Poisson est utilisee.

        float mowing_probability <-
            1.0 - exp(-tau_management * dt);

        if (rnd(1.0) < mowing_probability)  {

            mowing_event_this_month <- true;

            total_mowing_events <- total_mowing_events + 1;

            // Chaque couronne est fauchee independamment
            // avec la probabilite mowing_fraction.

            ask Couronne {

                if (rnd(1.0) < proportion_mowing) {

                    do mow;
                }
            }
        }
    }
}


// =========================================================
// GRILLE D'AFFICHAGE
// =========================================================

grid Parcelle
    width: grid_width
    height: grid_height
    neighbors: 8 {

    bool occupied <- false;

    reflex update_cell {

        occupied <-
            length(Couronne inside self) > 0;

        if (occupied) {
            color <- #green;
        } else {
            color <- #white;
        }
    }
}


// =========================================================
// EXPERIENCE GUI
// =========================================================

experiment Management_gui type: gui {

    parameter "Frequence moyenne tau (fauches/an)"
        var: tau_management
        min: 0.0
        max: 15.0
        step: 0.5;

    parameter "Duree de gestion (mois)"
        var: management_duration_months
        min: 12
        max: 240
        step: 12;

    parameter "Seuil de population"
        var: target_population
        min: 100
        max: 3000
        step: 100;

    output {

        display main_display type: opengl {

            species Parcelle;
            species Couronne aspect: base;
        }
    }
}


experiment Management_batch type: batch repeat: 50 keep_seed: false until: simulation_finished  {
	parameter
	 "Management tau:" 
	 var: tau_management 
	 among: [0.0, 1.5,  2.0, 2.5, 3.0, 3.5,  4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10
	 	, 10.5, 11, 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15
	 ];
	parameter "Batch mode:" var: is_batch <- true;
	
	init {
        sim_id <- rnd(100000);  // identifiant unique
    }
	
	
	//method tabu maximize: nb_preys + nb_predators iter_max: 10 tabu_list_size: 3;
	
	
	/*reflex save_results_explo {
		ask simulations {
			//save [int(self),prey_max_transfer,prey_energy_reproduce,predator_energy_transfer,predator_energy_reproduce,self.nb_predators,self.nb_preys] 
		   		//to: "results.csv" format:"csv" rewrite: (int(self) = 0) ? true : false header: true;
		   	  save [
    		tau_management,
    		cycle,
    		natural_months,
    		management_months,
    		management_months * dt,
    		total_mowing_events,
    		current_area,
    		current_population,
    		in_K,
    		ever_reached_K,
    		remained_in_K
    	]
    	to: "../results/knotweed_viability.csv"
       format:"csv"
       rewrite: (int(self) = 0) ? true : false header: true;
       
    	
		}		
	}*/
}



